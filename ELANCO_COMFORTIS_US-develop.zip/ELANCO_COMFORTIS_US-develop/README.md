Repository Name: ELANCO_COMFORTIS_US
Application Short Name: ELANCO_COMFORTIS_US
Repository Owner (Lilly Email Address): RASHMI SETHI (C232433)
Repository Owner (GitHub Username): rashmi-sethi
Responsible IT Organization: Elanco  IT
