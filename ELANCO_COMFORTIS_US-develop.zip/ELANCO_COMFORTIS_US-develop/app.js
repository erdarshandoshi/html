/* eslint-disable */
/* eslint-disable prefer-arrow-callback*/

// importing modules
const express = require('express');
const exphbs = require('express-handlebars');
const path = require('path');
const morgan = require('morgan');
const bodyParser = require('body-parser');
const compression = require('compression');
const favicon = require('serve-favicon');
const helmet = require('helmet');
const http = require('http');
const expressLogger = require('morgan');
const logger = require('./lib/logger').logger;
const basicAuth = require('basic-auth');
// const Authentication = require('./lib/web/Authentication');
// Importing the express module under the `app` variable
const app = express();

const WEB_HOOK_UNAME = process.env.WEB_HOOK_UNAME;
const WEB_HOOK_PW = process.env.WEB_HOOK_PW;

global.appServer = app;
/* If the user is local development import the .env file, else do not load the
.env file. Also if production is set start newrelic for monitoring*/
if (app.get('env') === 'development') {
  /* eslint-disable global-require */
  require('dotenv').config();
} else if (app.get('env') === 'production') {
  // Import the NewRelic Module.
  require('newrelic');
} else {
  console.log('Please set your NODE_ENV to either `development` or `production`');
}

// Importing the favicon, remove if you do not have one.
app.use(favicon(`${__dirname}/lib/public/favicon.ico`));

// Added further layer of security
app.use(helmet());

// Importing all routes to the server
const authenticatedRoutes = require('./lib/routes/authenticated-routes');
const contentful = require('contentful');
const utilities = require('./lib/web/Utilities');
const cfHelpers = require('./lib/web/global_variables');

// Configure the express app
app.use(morgan('combined'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
  extended: false,
}));

const server = http.createServer(app);
const io = require('socket.io')(server);

exports.writeMessage = function writeMessage(message) {
  io.sockets.emit('msg', { msg: message });
};

io.on('connection', (socket) => {
  socket.emit('msg', { msg: 'Connected to Indexer' });
});

const indexer = require('./lib/web/indexer');

// Configure the express app
app.use(expressLogger(process.env.LOG_LEVEL));
app.use(bodyParser.json({ type: 'application/*' }));
app.use(bodyParser.urlencoded({
  extended: false,
}));

// Configure the session middleware
require('./lib/web/sessions')(app);

// Routes for the webhook handler
// app.post('/handler', (req, res) => {
//   const credentials = basicAuth(req);
//   if (!credentials || credentials.name !== WEB_HOOK_UNAME || credentials.pass !== WEB_HOOK_PW) {
//     res.statusCode = 401;
//     res.setHeader('WWW-Authenticate', 'Basic realm');
//     res.end('Access denied');
//   } else {
//     switch (req.get('x-contentful-topic')) {
//       case 'ContentManagement.Entry.publish': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received PUBLISH on resourcePage: ${JSON.stringify(req.body)}`);
//         if (req.body.sys.contentType.sys.id === 'resourcePage') {
//           indexer.indexResourcePage(req.body.sys.id);
//         }
//         break;
//       }
//       case 'ContentManagement.Entry.unpublish': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received UNPUBLISH on resourcePage: ${JSON.stringify(req.body)}`);
//         if (req.body.sys.contentType.sys.id === 'resourcePage') {
//           indexer.deleteIndexItem(req.body.sys.id);
//         }
//         break;
//       }
//       case 'ContentManagement.Entry.delete': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received DELETE on resourcePage: ${JSON.stringify(req.body)}`);
//         if (req.body.sys.contentType.sys.id === 'resourcePage') {
//           indexer.deleteIndexItem(req.body.sys.id);
//         }
//         break;
//       }
//       case 'ContentManagement.Asset.publish': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received PUBLISH on media asset: ${JSON.stringify(req.body)}`);
//         if (req.body.sys.type === 'Asset') {
//           indexer.indexMediaAsset(req.body.sys.id);
//         }
//         break;
//       }
//       case 'ContentManagement.Asset.unpublish': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received UNPUBLISH on media asset: ${JSON.stringify(req.body)}`);
//         indexer.deleteIndexItem(req.body.sys.id);
//         break;
//       }
//       case 'ContentManagement.Asset.delete': {
//         logger('debug', 'webhook-handler-routes.js', `Webhook handler received DELETE on media asset: ${JSON.stringify(req.body)}`);
//         indexer.deleteIndexItem(req.body.sys.id);
//         break;
//       }
//       default:
//         logger('debug', 'webhook-handler-routes.js', `default code block: ${req.get('x-contentful-topic')}`);
//     }
//     res.status(200).end('Access granted');
//   }
// });


const cfClient = contentful.createClient({
  // This is the space ID. A space is like a project folder in Contentful terms
  space: process.env.CONTENTFUL_SPACEID,
  // This is the access token for this space.
  // Normally you get both ID and the token in the Contentful web app
  accessToken: process.env.CONTENTFUL_ACCESSTOKEN,
  agent: utilities.createProxyAgent(),
});
// put instance of contentful client in global variables
global.cfClient = cfClient;

// set the locale in which we are currently viewing the application
global.appLocale = 'en-US';
global.appServer.locals.tealiumSyncURL = process.env.TEALIUM_SYNC_URL;
global.appServer.locals.tealiumAsyncURL = process.env.TEALIUM_ASYNC_URL;
global.appServer.locals.GTMScript = process.env.GTM_SCRIPT;
global.appServer.locals.tealiumScript = process.env.TEALIUM_SCRIPT;
// compress all routes
app.use(compression());

// view engine setup and public static directory
app.set('views', path.join(__dirname, 'views'));
app.engine('handlebars', exphbs({ defaultLayout: 'main' }));
app.set('view engine', 'handlebars');
app.use(express.static(path.join(__dirname, 'lib/public')));
//
// app.all('/*', Authentication.BasicAuthentication, (req, res, next) => {
// 	  next();
// 	  cfHelpers.GetGlobalEntriesAppData();
// 	});
  app.all('/*', function(req, res, next) {
    next();
    cfHelpers.GetGlobalEntriesAppData();
  });

// Load authenticated routes
app.use('/', authenticatedRoutes);

app.post('/indexfull', (req, res) => {
  indexer.indexFull();
  res.status = 200;
  res.end();
});

app.post('/clearindex', (req, res) => {
  indexer.clearIndex();
  res.status = 200;
  res.end();
});

// catch 404 and forward to error handler
app.use((req, res, next) => {
  const err = new Error('Page Not Found');
  err.status = 404;
  next(err);
});

// development error handler will print stck trace
// To run in development mode set config var NODE_ENV to 'development'
if (app.get('env') === 'development') {
  app.use((err, req, res) => {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err,
    });
  });
}

// production error handler. No stacktraces leaked to user
app.use((err, req, res) => {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {},
  });
});

module.exports = app;
