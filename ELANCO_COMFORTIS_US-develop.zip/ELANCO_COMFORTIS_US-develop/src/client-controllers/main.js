/* This is the file that browserfiy reads */

/*  The below way is the methof of importing modules and how to call modules
    DELETE THIS CODE WHEN USING THE CODE IT IS ONLY FOR SHOW */
import helper from './helper';

const obj = {
  Name: 'Test',
};

const truthy = helper.objectEmpty(obj);

console.log(truthy);
