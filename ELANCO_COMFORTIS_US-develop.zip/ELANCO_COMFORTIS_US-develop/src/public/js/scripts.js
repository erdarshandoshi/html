/* eslint-disable */
/*****************************************************************************************
Copyright (c) 2016 Elanco Animal Health.
This software is the confidential and proprietary information of Elanco Animal Health, a division
of Eli Lilly and Company. ("Confidential Information"). You shall not disclose such Confidential
Information and shall use it only in accordance with the terms of the license agreement you entered
into with Elanco Animal Health.
VERSION 1.0
*****************************************************************************************/
/* =DEVICE CHECKER
---------------------------------------------------------------------------------------*/
// Requires <div id="deviceChecker"><!-- --></div> in markup
function isMobile() {
	//Prevent sloppy coding
	"use strict";
	var response = ($('#deviceChecker').css('display') === 'block') ? true : false;
	return response;
}
/**/
function iOS() {
  "use strict";
  if (/iP(ad|hone|od)/.test(navigator.userAgent) && !window.MSStream) {
    var v = (navigator.appVersion).match(/OS (\d+)_(\d+)_?(\d+)?/);
    var ver = [parseInt(v[1], 10), parseInt(v[2], 10), parseInt(v[3] || 0, 10)];
    if (ver[0] < 10 && !$('html').hasClass('iOS')) {
      $('html').addClass('iOS');
    }
  }
}
/* =CROSS BROWSER PREVENT DEFAULT
---------------------------------------------------------------------------------------*/
function preventReturn(ev) {
	//Prevent sloppy coding
	"use strict";
	if (ev.preventDefault) {
		ev.preventDefault();
	}
	else {
		ev.returnValue = false;
	}
}
/**/

/* =CROSS BROWSER LOAD EVENT
---------------------------------------------------------------------------------------*/
function addLoadEvent(func) {
	//Prevent sloppy coding
	"use strict";
	var oldonload = window.onload;
	if (typeof window.onload != 'function') {
		window.onload = func;
	}
	else {
		window.onload = function() {
			if (oldonload) {
				oldonload();
			}
			func();
		};
	}
}
/**/
/* =PATHNAME VARIABLES
---------------------------------------------------------------------------------------*/
var currentPathArray = window.location.pathname.split('/'),
	pathSection,
	pathSubsection,
	pathPage;
if (currentPathArray.length > 0) {
	pathSection = currentPathArray[1];
	if (currentPathArray.length > 1) {
		pathSubsection = currentPathArray [2];
		pathPage = currentPathArray[3];
	}
	else {
		pathPage = currentPathArray[2];
	}
}
else {
	pathPage = currentPathArray[1];
}
/**/
/* =INTERSTITIAL FOR REMINDERS BUTTON
---------------------------------------------------------------------------------------*/
$(".modalNoticeMessage").hide();
$('.modalNotice').on('click', function(e){
        //Prevent sloppy coding
        "use strict";
        preventReturn(e);
        $(".modalNoticeMessage").show();
});
$('.modalNoticeClose').on('click', function(e){
  //Prevent sloppy coding
  "use strict";
  preventReturn(e);
  $(".modalNoticeMessage").hide();
});
/**/
var $searchTab = $('#primaryNav .search-tab'),
    $searchTabNav = $('#primaryNav .search-container'),
    $menuTab = $('#primaryNav .menu-tab'),
    $menuTabNav = $('#primaryNav .nav'),
    $menuTabSubNavs = $('#primaryNav .sub-nav'),
    $menuTabButtons = $('#primaryNav .nav-arrow'),
    $socialTab = $('.share-menu'),
    $socialNav = $('.blog-share');
$searchTab.on('click', function(e){
  "use strict";
  preventReturn(e);
  var $button = $(this),
      $menu = $button.siblings('.search-container');
  $menuTab.removeClass('open');
  $menuTabNav.removeClass('open');
  if ($button.hasClass('open')) {
    $button.removeClass('open');
    $menu.removeClass('open');
    $button.focus();
  }
  else {
    $button.addClass('open');
    $menu.addClass('open');
    $('#search-bar').focus();
  }
});
$menuTab.on('click', function(e){
  "use strict";
  preventReturn(e);
  var $button = $(this),
      $menu = $button.siblings('.nav');
  $searchTab.removeClass('open');
  $searchTabNav.removeClass('open');
  // close the menu
  if ($button.hasClass('open')) {
    $button.removeClass('open');
    $menu.removeClass('open');
  }
   //open the menu and reset any opened sub-navs
  else {
    if($('#primaryNav .sub-nav').hasClass('open')) {
      $('#primaryNav .sub-nav').removeClass('open');
    }
    $button.addClass('open');
    $menu.addClass('open');
    $menuTabButtons.removeClass('close');
    $('#primaryNav .buttonText.selected .nav-arrow').addClass('close');
    $('#primaryNav .buttonText.selected .sub-nav').addClass('open');
  }
});
$('#primaryNav .nav-arrow, #primaryNav .nav-not-arrow').on('click', function(e){
  if(isMobile()) { // MOBILE VIEW

    preventReturn(e);
  	var $button = $(this),
      	$menu = $button.parent().next('.sub-nav');

  	//If you want to collapse sub-nav
  	if ($button.hasClass('close')) {
    	$button.removeClass('close');
    	$menu.removeClass('open');
  	}
  	else {
    	// If other sub-navs are expanded upon clicking an arrow
    	if ($menuTabSubNavs.hasClass('open')) {
      		$menuTabButtons.removeClass('close');
           $menuTabSubNavs.removeClass('open');
      		$button.addClass('close');
      		$menu.addClass('open');
    	}
    	// Expand the sub nav
    	else {
      		$button.addClass('close');
          $menu.addClass('open');
    	}
  	}
  }
});
/**/
/* =SUB NAVIGATION
---------------------------------------------------------------------------------------*/
function initSubNav() {
	//Prevent sloppy coding
	"use strict";
	if(isMobile()) { // MOBILE VIEW
		// remove sidebar if it exists
		if ($('#secondaryNav').length >= 0) {
			$('#secondaryNav .sub-nav').remove();
			$('#secondaryNav').remove();
		}
		var viewPort = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
		// curves text in the navigation using CircleType.js
		if((viewPort > 650) && (viewPort < 768)) {
			$('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 3000, dir: -1}); // originally 2000
		}
		if((viewPort > 480) && (viewPort < 651)) {
			$('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 2000, dir: -1});
		}
		if((viewPort > 400) && (viewPort < 481)) {
			$('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 1000, dir: -1});
		}
		if(viewPort < 401) {
			$('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 700, dir: -1});
		}
	}
	else { // DESKTOP VIEW
		// immediately hide the sub-nav
		$('#primaryNav .sub-nav').hide();
		var $pageContent = $('#pageContent');
		$('#secondaryNav').hcSticky();
		$pageContent.children('.row').not('.toutFooter').children().css('float', 'none');
		// check if current page has an associated section (see PATHNAME VARIABLES)
		/* if (pathSection.length > 1) {
			var $pageContent = $('#pageContent'),
			$sectionNav = $('#primaryNav .nav > li > a[href*="' + pathSection + '"]').next('.sub-nav');
			// confirm sidebar doesn't exist and current section has multiple pages
			if (!$('#secondaryNav').length && $sectionNav.length > 0) {
				// add sidebar to page content container
				$pageContent.prepend('<div id="secondaryNav" class="sidebar"><ul class="sub-nav">' + $sectionNav.html() + '</ul></div>');
				$('#secondaryNav').hcSticky();
				$pageContent.children('.row').not('.toutFooter').children().css('float', 'none');
			}
		} */
	}
}
/**/
/* =BACK-TO-TOP BUTTON
---------------------------------------------------------------------------------------*/
// http://codepen.io/rdallaire/pen/apoyx
$(window).scroll(function() {
	if ($(this).scrollTop() >= 200) {   // If page is scrolled more than 200px
		$('#backToTop').fadeIn(200);    // Fade in the arrow
	} else {
		$('#backToTop').fadeOut(200);   // Else fade out the arrow
	}
});
$('#backToTop').click(function() {      // When arrow is clicked
	$('body,html').animate({
		scrollTop : 0                   // Scroll to top of body
	}, 500);
});
/**/
/* Rollover title ---------------------------------------------------------------------------- */
function rolloverTitle(){
  var offsiteImg = '<span class="offsiteImg">&nbsp;&nbsp;&nbsp;&nbsp;</span>',
      defaultTitle = "Please note: If you click this link, you will be leaving Elanco's website InterceptorPlus.com. Different privacy policies and/or terms and conditions may apply.",
      blankTarget = '_blank';
    $(offsiteImg).insertAfter("a.offsite:not(footer.global .affiliateLinks a.offsite)");
    $("a.offsite, a.offsiteImage").not($("footer.global .affiliateLinks a.offsite")).attr({
      title: defaultTitle,
      target: blankTarget
    });
  $("footer.global .affiliateLinks a.offsite").attr({
      target: blankTarget
    });
    if ((!isMobile()) && (!(Modernizr.touch))) {
      $('a.offsite, a.offsiteImage').not($("footer.global .affiliateLinks a.offsite")).hoverbox();
      $('footer.global a.offsiteImage').hoverbox({left:-210,top:100});
    }
  else {
     $("a.offsite, a.offsiteImage").not($("footer.global .affiliateLinks a.offsite")).each(function(index){
      $(this).click(function(e){
        preventReturn(e);
        alert($(this).attr('title'));
        newWinURL = $(this).attr('href');
        window.open(newWinURL);
      });
   });
  }
}
/**/
/* Open a new fullpage window ----------------------------------------------------------------- */
function newWindow(){ /* .newWindow class also adds the new window graphic. See style.css */
	//Prevent sloppy coding
	"use strict";
	//Open in a new full size window
	if ($.cookie("interactiveComponents") != "disabled") {
		$("a.newWindow").attr({ target: '_blank' });
	}
}
function newWindowNoIcon(){ /* Opens in a new window without the graphic */
	//Prevent sloppy coding
	"use strict";
	//Open in a new full size window
	if ($.cookie("interactiveComponents") != "disabled") {
		$("a.newWindowNoIcon").attr({ target: '_blank' });
	}
}
/**/
/* Pop-up window ---------------------------------------------------------------------------- */
function popOpen(){
	//Prevent sloppy coding
	"use strict";
	if ($.cookie("interactiveComponents") != "disabled") {
		$('a.popUp').click(function(){
			window.open(this.href,"popOpen","toolbar=no, location=no, directories=no, status=no, menubar=yes, scrollbars=yes, resizable=yes, width=600,height=500");
			return false;
		});
	}
}
/**/
/* Accordion menu ---------------------------------------------------------------------------- */

function accordion(){
	//Prevent sloppy coding
	"use strict";
	//slides the element with class "item_body" when paragraph with class "item_head" is clicked
	$("div.item_body").hide();
	$(".accordion .item_head").click( function() {
		var questionOpened = $(this).hasClass("open");
		if (!questionOpened) {
			$(this).addClass("open");
			$(this).next("div.item_body").slideDown(300);
			$(this).find("span.plus").toggleClass("plus minus");
		}
		else /* if (questionOpened) */ {
			$(this).removeClass("open");
			$(this).next("div.item_body").slideUp(300);
			$(this).find("span.minus").toggleClass("plus minus");
		}
		//Webtrends call. This is needed since there is no href (it's not a true link). The text is styled as a link.
		//dcsMultiTrack('DCS.dcsuri','/reveal/howtodownloadwallpapers', 'DCSext.page_name','downloads/default.aspx');
	});
}
/**/
/* =DISABLE RIGHT CLICK
---------------------------------------------------------------------------------------*/
//Remove ability to save images, via right-click.
$('img').bind('contextmenu', function(e) {
	//Prevent sloppy coding
	"use strict";
	return false;
});
/**/
/* =YOUTUBE PLAYER API
---------------------------------------------------------------------------------------*/
if (!window['YT']) {
	var YT = {loading: 0,loaded: 0};
}
if (!window['YTConfig']) {
	var YTConfig = {'host': 'http://www.youtube.com'
	};
}
if (!YT.loading) {
	YT.loading = 1;
	(function(){
		var l = [];
		YT.ready = function(f) {
			if (YT.loaded) {
				f();
			}
			else {
				l.push(f);
			}
		};
	window.onYTReady = function() {
		YT.loaded = 1;
		for (var i = 0; i < l.length; i++) {
			try {l[i]();}
			catch (e) {}
		}
	};
	YT.setConfig = function(c) {
		for (var k in c) {
			if (c.hasOwnProperty(k)) {
			  YTConfig[k] = c[k];
			}
		}
	};
	var a = document.createElement('script');
	a.type = 'text/javascript';
	a.id = 'www-widgetapi-script';
	a.src = 'https:' + '//s.ytimg.com/yts/jsbin/www-widgetapi-vflmItlsD/www-widgetapi.js';
	a.async = true;
	var b = document.getElementsByTagName('script')[0];
	b.parentNode.insertBefore(a, b);
	})();
}
/**/
var absoluteRoot = window.location.protocol + '//' + window.location.host,
players = {},
player,
lastPlayed = '',
videoStatus = 'pause';
/* =YOUTUBE EVENT TRACKING
---------------------------------------------------------------------------------------*/
// derived from answer by Rob W. - http://stackoverflow.com/questions/8948403/youtube-api-target-multiple-existing-iframes
function onYouTubeIframeAPIReady() {
	//Prevent sloppy coding
	"use strict";
	$('.videoContainer iframe[id]').each(function() {
		var identifier = this.id,
			youtubeUrl = this.src,
			youtubeId = youtubeUrl.slice(youtubeUrl.indexOf('embed/') + 6, youtubeUrl.indexOf('?')),
			source = youtubeUrl + '&enablejsapi=1&origin=' + absoluteRoot;
    		this.src = source;
		if (identifier) {
			players[identifier] = new YT.Player(identifier, {
				events: {
					'onStateChange': onPlayerStateChange(identifier, youtubeId)
				}
			});
		}
	});
}
function trackStatus(vidId, vidStat, youtubeId) {
	//Prevent sloppy coding
	"use strict";
	if (vidId) {
		if (youtubeId && videoStatus !== vidStat) {
			var simpleKey = 'AIzaSyAicQPs8fSHUW6Z5GYHBa0wARB6nfLcVTg',
				youtubeStatus = '';
			switch (vidStat) {
				case 'play':
				youtubeStatus = 'Play';
				break;
				case 'ended':
				youtubeStatus = 'End Video';
				break;
				default:
				break;
			}
			$.getJSON('https://www.googleapis.com/youtube/v3/videos?id=' + youtubeId + '&key=' + simpleKey + '&part=snippet', function(data){
				var youtubeTitle = data.items[0].snippet.title;
				dataLayer.push({'event': 'GAEvent','eventCategory': 'Video','eventAction': youtubeStatus,'eventLabel': youtubeTitle});
				console.log('--> valid action taken on "' + youtubeTitle + '"');
			});
		}
		else if (videoStatus === vidStat) {
			console.log('--> no action is required: new video event matches previously defined event');
		}
		else {
			console.log('--> "youtubeId" (optional) was not defined in trackStatus call');
		}
		lastPlayed = '#' + vidId;
		videoStatus = vidStat;
	}
	else {
		console.log('--> "vidId" was not defined in trackStatus call');
	}
}
function stopYouTube() {
	//Prevent sloppy coding
	"use strict";
	var lastPlayId = lastPlayed.replace(/#/g, '');
	players[lastPlayId].pauseVideo();
}
/**/
/* =Youtube video auto-resizer script created by Skipser.com
---------------------------------------------------------------------------------------*/
$().ready(function() {
	//Prevent sloppy coding
	"use strict";
	if(typeof YOUTUBE_VIDEO_MARGIN === 'undefined') {
		var YOUTUBE_VIDEO_MARGIN = 0;
	}
	$('iframe').each(function(index,item) {
	    if($(item).attr('src').match(/(https?:)?\/\/www\.youtube\.com/)) {
			var w=$(item).attr('width');
			var h=$(item).attr('height');
			var ar = h/w*100;
			ar=ar.toFixed(2);
			//Style iframe
			$(item).css({'position':'absolute',
				'top':'0',
				'left':'0',
				'width':'100%',
				'height':'100%',
				'max-width': w+'px',
				//'max-width': '100%',
				//'max-height': auto'
				'max-height': h+'px'
			});
        //removed margin 0 auto
			$(item).wrap('<div style="max-width:'+w+'px; padding:'+YOUTUBE_VIDEO_MARGIN+'px;"></div>');
			$(item).wrap('<div style="position: relative;padding-bottom: '+ar+'%; height: 0; overflow: hidden;"></div>');
		}
	});
});
/**/
/* =REFERENCES VIEW MODEL (by Jarred Keuch, AppDev/CP)
---------------------------------------------------------------------------------------*/
// Moves the References into the Important Safety Info (ISI) area.
var ViewModel = function () {
	var self = this;
	this.debug = true;
	this.references = "";
	this.init = function () {
		// By default, KO applies bindings to <body>. We need to apply bindings at the <html> level to allow adjusting <head> tags.
		ko.applyBindings(self, document.getElementsByTagName("html")[0]);
	};
};
$(function () {
	viewModel = new ViewModel();
	// Set from the content page template...
	if (typeof references !== 'undefined') viewModel.references = references;
	// Now that we've set the parameters as necessary, we can load JSON and bind.
	viewModel.init();
});
/**/
/* =DEBOUNCE (https://davidwalsh.name/javascript-debounce-function)
---------------------------------------------------------------------------------------*/
// Returns a function, that, as long as it continues to be invoked, will not
// be triggered. The function will be called after it stops being called for
// N milliseconds. If `immediate` is passed, trigger the function on the
// leading edge, instead of the trailing.
function debounce(func, wait, immediate) {
	//Prevent sloppy coding
	"use strict";
	var timeout;
	return function() {
		var context = this, args = arguments;
		var later = function() {
				timeout = null;
				if (!immediate) func.apply(context, args);
			};
		var callNow = immediate && !timeout;
		clearTimeout(timeout);
		timeout = setTimeout(later, wait);
		if (callNow) func.apply(context, args);
	};
}
/**/
var checkDevice = debounce(function() {
	//Prevent sloppy coding
	"use strict";
	if (isMobile()) { // MOBILE VIEW
      $('#secondaryNav .sub-nav').hide();
      $('#secondaryNav').hide();
      $('.sidebar').hide();

    // remove sidebar if it exists - TRY THIS AFTER WORK
    // if ($('#secondaryNav').length >= 0) {
     // $('#secondaryNav .sub-nav').remove();
     // $('#secondaryNav').remove();
    //}

    // if ($(window).width() != windowWidth) {
            // Update the window width for next time
            // windowWidth = $(window).width();
            // Do stuff here
            // cleanup primary nav items
		// $menuTab.removeClass('open');
		// $menuTabNav.removeClass('open');
		// $menuTabButtons.removeClass('close');
    // alert('closed');
     //   }

    if($('header.global .sub-nav').attr('style')) {
      $('header.global .sub-nav').removeAttr('style');
    }

		var viewPort = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
      if((viewPort > 650) && (viewPort < 768)) {
        $('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 3000, dir: -1}); // originally 2000
      }
      if((viewPort > 480) && (viewPort < 651)) {
        $('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 2000, dir: -1});
      }
      if((viewPort > 400) && (viewPort < 481)) {
        $('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 1000, dir: -1});
      }
      if(viewPort < 401) {
        $('header.global .nav a > span, header.global .sub-nav a > span').circleType({radius: 700, dir: -1});
      }

  	}
	else { // DESKTOP VIEW
		// immediately hide the sub-nav
		$('#primaryNav .sub-nav').hide();

		// destroy CircleType plugin
		$('header.global .nav a > span > span').contents().unwrap();
		$('header.global .nav a > span').removeAttr('aria-label style');

	}
	$searchTab.show();
	initSubNav();
}, 250);
if (window.addEventListener) {
	window.addEventListener("resize", checkDevice, false);
}
else {
	window.attachEvent("onresize", checkDevice);
}
/* =DOCUMENT READY
---------------------------------------------------------------------------------------*/
$().ready(function() {
	//Prevent sloppy coding
	"use strict";
	// search button
	$('#search-btn').on('click', function(e) {
		e.preventDefault();
		location.href = '/search.aspx?q=' + $('#search-bar').val();
	});
	// search when enter key is clicked inside of search field
	$('#search-bar').on('keyup', function(e) {
		if (e.keyCode == 13) {
			location.href = '/search.aspx?q=' + $('#search-bar').val();
		}
	});

	//Call the functions on page load
  iOS();
	initSubNav();
	accordion();
	rolloverTitle();
	//open new fullsize window with new window graphic
	newWindow();
	//open new fullsize window without new window graphic
	newWindowNoIcon();
	//pop-up window (used for footer information)
	popOpen();
	//used for desktop download instructions
});
