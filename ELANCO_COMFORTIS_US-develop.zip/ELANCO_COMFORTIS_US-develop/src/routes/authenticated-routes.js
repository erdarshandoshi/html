/* eslint-disable linebreak-style*/
// 'use strict';

const express = require('express');

function interopRequireDefault(obj) { return obj && obj.esModule ? obj : { default: obj }; }
const express2 = interopRequireDefault(express);

const cirrusAuthModule = require('cirrus-auth-module');

const cirrusAuthModule2 = interopRequireDefault(cirrusAuthModule);

const test = require('../server-controllers/test');

const test2 = interopRequireDefault(test);

// Importing authentication flow
const router = express2.default.Router();

// authenticate our router


// Importing the server side modules.
// Routes in this module require authentication
const index = require('../web/index');
const aboutfleas = require('../web/about-fleas');
const rebatesreminders = require('../web/rebates-reminders');
const faqs = require('../web/faq');
const aboutcomfortis = require('../web/about-comfortis');
const dosingadministration = require('../web/dosing-administration');
const howtogetcomfortis = require('../web/how-to-get-comfortis');
const whatarefleas = require('../web/what-are-fleas');
const flealifecycle = require('../web/flea-life-cycle');
const controllingfleas = require('../web/controlling-fleas');
const trademark = require('../web/trademark');
const termsOfUse = require('../web/terms-of-use');
const aboutelanco = require('../web/about-elanco');
const contactus = require('../web/contact-us');
const ourGurantee = require('../web/our-guarantee');
const referencematerial = require('../web/reference-materials');
const ourpartners = require('../web/our-partners');
const pageNotFound = require('../web/page-not-found');
const ourbrands = require('../web/our-brands');
const sitemap = require('../web/site-map');
const generalQuestions = require('../web/general-questions');
const effectiveness = require('../web/effectiveness');
const safety = require('../web/safety');
const administration = require('../web/administration');

cirrusAuthModule2.default.authenticate(router);

router.get('/', (req, res, next) => {
  index.getIndexPage(req, res, next);
});
router.get('/index', (req, res, next) => {
  index.getIndexPage(req, res, next);
});
router.get('/safety', (req, res, next) => {
  safety.getsafetyPage(req, res, next);
});
router.get('/about-fleas', (req, res, next) => {
  aboutfleas.getaboutfleasPage(req, res, next);
});
router.get('/rebates-reminders', (req, res, next) => {
  rebatesreminders.getrebatesremindersPage(req, res, next);
});
router.get('/faq', (req, res, next) => {
  faqs.getfaqsPage(req, res, next);
});
router.get('/about-comfortis', (req, res, next) => {
  aboutcomfortis.getaboutcomfortisPage(req, res, next);
});
router.get('/dosing-administration', (req, res, next) => {
  dosingadministration.getdosingadministrationPage(req, res, next);
});
router.get('/how-to-get-comfortis', (req, res, next) => {
  howtogetcomfortis.gethowtogetcomfortisPage(req, res, next);
});
router.get('/what-are-fleas', (req, res, next) => {
  whatarefleas.getwhatarefleasPage(req, res, next);
});
router.get('/flea-life-cycle', (req, res, next) => {
  flealifecycle.getflealifecyclePage(req, res, next);
});
router.get('/controlling-fleas', (req, res, next) => {
  controllingfleas.getcontrollingfleasPage(req, res, next);
});
router.get('/trademark', (req, res, next) => {
  trademark.gettrademarkPage(req, res, next);
});
router.get('/terms-of-use', (req, res, next) => {
  termsOfUse.gettermsOfUsePage(req, res, next);
});
router.get('/about-elanco', (req, res, next) => {
  aboutelanco.getaboutelancoPage(req, res, next);
});
router.get('/contact-us', (req, res, next) => {
  contactus.getcontactusPage(req, res, next);
});
router.get('/our-guarantee', (req, res, next) => {
  ourGurantee.getourGuranteePage(req, res, next);
});
router.get('/reference-materials', (req, res, next) => {
  referencematerial.getreferencematerialPage(req, res, next);
});
router.get('/our-partners', (req, res, next) => {
  ourpartners.getourpartnersPage(req, res, next);
});
router.get('/page-not-found', (req, res, next) => {
  pageNotFound.getpageNotFoundPage(req, res, next);
});
router.get('/our-brands', (req, res, next) => {
  ourbrands.getourbrandsPage(req, res, next);
});
router.get('/site-map', (req, res, next) => {
  sitemap.getsitemapPage(req, res, next);
});
router.get('/general-questions', (req, res, next) => {
  generalQuestions.getgeneralQuestionsPage(req, res, next);
});
router.get('/effectiveness', (req, res, next) => {
  effectiveness.geteffectivenessPage(req, res, next);
});
router.get('/administration', (req, res, next) => {
  administration.getadministrationPage(req, res, next);
});

router.get('/about', (req, res) => {
  test2.default.test().then((data) => {
    return res.render('about', {
      title: data,
    });
  }).catch((e) => {
    res.status(500, {
      error: e,
    });
  });
});

module.exports = router;
