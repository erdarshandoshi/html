/* eslint-disable linebreak-style*/
exports.createProxyAgent = () => {
  let proxyAgent;
  if (process.env.NODE_ENV === 'development') {
/* eslint-disable global-require */
    const HttpsProxyAgent = require('https-proxy-agent');
/* eslint-enable global-require */
// HTTP/HTTPS proxy to connect to
    const proxy = process.env.PROXY;
    console.log('Using proxy server: %s', proxy);
// create an instance of the `HttpsProxyAgent` class with the proxy server information
    proxyAgent = new HttpsProxyAgent(proxy);
  }
  return proxyAgent;
};


exports.masterPageHeader = function () {
  this.headerLogo = '';
  this.headerLogoUrl = '';
  this.headerMenuLink = [];
};

exports.headerMenuLink = function () {
  this.menuName = '';
  this.menuUrl = '';
  this.leftnav = [];
  this.haveleftnav = '';
  this.class = '';
  this.style = '';
};


exports.leftnav = function () {
  this.pagename = '';
  this.pageurl = '';
  this.class = '';
  this.style = '';
};


exports.masterPageFooter = function () {
  this.copyText = '';
  this.zincCode = '';
  this.footerMenuLink = [];
  this.elancoLogo = '';
  this.elancoUrl = '';
};
exports.footerMenuLink = function () {
  this.menuName = '';
  this.menuUrl = '';
};

exports.homePage = function () {
  this.prescribedText = '';
  this.saveText = '';
  this.saveUrl = '';
  this.learnWhyButton = '';
  this.learnWhyButtonUrl = '';
  this.fleaMedicineText = '';
  this.bannerimage2 = '';
  this.bannercontent2 = '';
  this.image = '';
  this.imagemobile = '';
  this.mandatory = '';
  this.banner3 = '';
  this.banner1Title = '';
  this.banner1BottomText = '';
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
};

exports.impSafetyInfo = function () {
  this.impSafetyTitle = '';
  this.impSafetyContent = '';
};

exports.about = function () {
  this.name = '';
  this.url = '';
};

exports.dvmstaff = function () {
  this.name = '';
  this.url = '';
};

exports.references = function () {
  this.references = '';
};

exports.aboutfleasPage = function () {
  this.bannertitle = '';
  this.bannerimage = '';
  this.howtogetridcontent = '';
  this.learnmoreaboutcomfirtis = '';
  this.learnmoreaboutcomfortisurls = '';
  this.askaveteriantext = '';
  this.askavetcontent = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.videoUrl1 = '';
  this.videoText1 = '';
  this.pdf1 = '';
  this.videoUrl2 = '';
  this.videoText2 = '';
  this.leftnav = '';
};

exports.learnhowtogetcomfortis = function () {
  this.learnhow = '';
};

exports.rebatesremindersPage = function () {
  this.rebatesreminderstitle = '';
  this.image = '';
  this.rebateofferstext = '';
  this.rebateofferssubtext = '';
  this.blueicon = '';
  this.visitrebatebutton = '';
  this.visitrebatebuttonurl = '';
  this.remindertitle = '';
  this.reminderssubtitle = '';
  this.reminderscontent = '';
  this.signupbutton = '';
  this.signupbuttonurl = '';
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
};

exports.faqsPage = function () {
  this.faqtitle = '';
  this.faqimg = '';
  this.faqtitle1 = '';
  this.faqcontent = '';
  this.faqmenu = [];
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
};

exports.faqmenu = function () {
  this.faqimage = '';
  this.url = '';
};

exports.aboutcomfortisPage = function () {
  this.bannertext = '';
  this.bannerimage = '';
  this.menu = '';
  this.title1 = '';
  this.content1 = '';
  this.familyfriendly = '';
  this.title2 = '';
  this.title2content = '';
  this.textli = '';
  this.viewthecomfortis = '';
  this.learnmoreaboutdosingbuttontext = '';
  this.learnmoreaboutdosingbuttonurl = '';
  this.askyourvettext = '';
  this.greenchemistrytitle = '';
  this.greenchemistrycontent = '';
  this.greenchemistryimage = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
  this.image1 = '';
  this.image2 = '';
};

exports.dosingandadministrationPage = function () {
  this.bannertitle = '';
  this.bannerimage = '';
  this.menu = '';
  this.howtogivetitle = '';
  this.howtogivecontent = [];
  this.dosinginformation = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.howtogivecontent = function () {
  this.icon = '';
  this.content = '';
  this.altText = '';
};
exports.howtogetcomfortisPage = function () {
  this.bannertitle = '';
  this.bannerimage = '';
  this.menu = '';
  this.title1 = '';
  this.titlecontent = '';
  this.blueicon = '';
  this.save25buttontitle = '';
  this.save25buttonurl = '';
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.whatarefleasPage = function () {
  this.whatarefleasbannertext = '';
  this.whatarefleaesimage = '';
  this.leftnav = '';
  this.herewhatyouneed = '';
  this.herewhatyouneedcontent = '';
  this.buttonText = '';
  this.buttonUrl = '';
  this.petthreat = '';
  this.humanthreattitle = '';
  this.humanthreat = '';
  this.buttonText1 = '';
  this.buttonUrl1 = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
};
exports.flealifecyclePage = function () {
  this.flealifecycletitle = '';
  this.flealifecycleimage = '';
  this.menu = '';
  this.stoppingafleatitle = '';
  this.stoppingafleacontent = '';
  this.lifecycleimage = '';
  this.howmypetgetfleas = '';
  this.comfortisspinosadtitle = '';
  this.content = '';
  this.learnmoreaboutbuttontitle = '';
  this.learnmoreaboutbuttonurl = '';
  this.videotitle = '';
  this.videourl = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.controllingfleasPage = function () {
  this.controllingfleastitle = '';
  this.image = '';
  this.menu = '';
  this.howtogetridfleas = '';
  this.howtogetridfleascontent = '';
  this.howtocontrolfleastitle = '';
  this.forfleastitle = '';
  this.fleasli = '';
  this.viewfaqs = '';
  this.viewfaqsurl = '';
  this.tipstofree = '';
  this.tipstofreecontent = '';
  this.killingfleastitle = '';
  this.killingfleascontent = '';
  this.preventingfuturetitle = '';
  this.preventingfuturecontent = '';
  this.howtogetcomfortistitle = '';
  this.howtogetcomfortisurl = '';
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
};
exports.trademarkPage = function () {
  this.trademarktitle = '';
  this.trademarkdescription = '';
  this.about = [];
  this.dvmstaff = [];
};
exports.termsOfUsePage = function () {
  this.title = '';
  this.description = '';
  this.about = [];
  this.dvmstaff = [];
};
exports.aboutelancoPage = function () {
  this.aboutelancotitle = '';
  this.aboutelancoimage = '';
  this.madebyelancotitle = '';
  this.madebyelancodescription = '';
  this.elilillycompanytitle = '';
  this.elilillycompanydescription = '';
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.contactusPage = function () {
  this.contactustitle = '';
  this.contactusimage = '';
  this.howtogetintouch = '';
  this.productinfo = '';
  this.number = '';
  this.mediacontacts = '';
  this.mediacontactsdescription = '';
  this.address = '';
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.ourGuranteePage = function () {
  this.ourguranteetitle = '';
  this.ourgurantee = '';
  this.productgurante = '';
  this.content = '';
  this.fleaicon = '';
  this.fleatitle = '';
  this.fleacontent = '';
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.referencematerialPage = function () {
  this.referencetitle = '';
  this.referenceimg = '';
  this.comfortistitle = '';
  this.comfortiscontent = '';
  this.productinfotitle = '';
  this.productinfocontent = '';
  this.fdainfo = '';
  this.fdacontent = '';
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
};
exports.ourpartnersPage = function () {
  this.ourpartnerstitle = '';
  this.ourpartnerimage = '';
  this.supportingthosetitle = '';
  this.partnermenu = [];
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
};
exports.partnermenu = function () {
  this.partnertitle = '';
  this.partnerimg = '';
  this.partnercontent = '';
};
exports.pageNotFoundPage = function () {
  this.bannerText = '';
  this.buttonText = '';
  this.buttonUrl = '';
  this.about = [];
  this.dvmstaff = [];
};
exports.ourbrandsPage = function () {
  this.ourbrandstitle = '';
  this.ourbrandsimage = '';
  this.innovativeproducts = '';
  this.brandmenu = [];
  this.learnhowtogetcomfortis = [];
  this.about = [];
  this.dvmstaff = [];
  this.references = [];
};
exports.brandmenu = function () {
  this.brandimg = '';
  this.imageAltText = '';
  this.brandcontent = '';
  this.learnmorebuttontitle = '';
  this.learnmorebuttonurl = '';
  this.isButton = '';
};
exports.sitemapPage = function () {
  this.sitemaptitle = '';
  this.aboutcomfortistitle = '';
  this.aboutcomfortismenu = [];
  this.aboutfleastitle = '';
  this.aboutfleasmenu = [];
  this.faqstitle = '';
  this.faqsmenu = [];
  this.rebatesreminderstitle = '';
  this.rebatesremindersurl = '';
  this.aboutelancotitle = '';
  this.aboutelancomenu = [];
  this.dvmstafftitle = '';
  this.dvmstaffmenu = [];
  this.privacystatementtitle = '';
  this.privacystatementurl = '';
  this.trademarkText = '';
  this.trademarkUrl = '';
  this.termsOfUseText = '';
  this.termsOfUseUrl = '';
  this.about = [];
  this.dvmstaff = [];
};

exports.aboutcomfortismenu = function () {
  this.name = '';
  this.url = '';
};
exports.aboutfleasmenu = function () {
  this.name = '';
  this.url = '';
};
exports.faqsmenu = function () {
  this.pagename = '';
  this.pageurl = '';
};
exports.aboutelancomenu = function () {
  this.name = '';
  this.url = '';
};
exports.dvmstaffmenu = function () {
  this.name = '';
  this.url = '';
};
exports.generalQuestionsPage = function () {
  this.faqtitle = '';
  this.faqimage = '';
  this.title = '';
  this.pageqa = [];
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.menu = '';
};
exports.pageqa = function () {
  this.pagetitle = '';
  this.question = '';
  this.answer = '';
};
exports.effectivenessPage = function () {
  this.faqtitle = '';
  this.faqimage = '';
  this.title = '';
  this.pageqa = [];
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.menu = '';
};
exports.safetyPage = function () {
  this.faqtitle = '';
  this.faqimage = '';
  this.title = '';
  this.pageqa = [];
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.menu = '';
};
exports.administrationPage = function () {
  this.faqtitle = '';
  this.faqimage = '';
  this.title = '';
  this.pageqa = [];
  this.learnhowtogetcomfortis = [];
  this.impSafetyInfo = [];
  this.about = [];
  this.dvmstaff = [];
  this.menu = '';
};
