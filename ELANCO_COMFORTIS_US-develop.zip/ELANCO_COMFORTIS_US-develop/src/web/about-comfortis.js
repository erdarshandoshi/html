/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');
 const async = require('../web/async');
/* global app.js cfClient:true appLocale:true*/
 exports.getaboutcomfortisPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'aboutcomfortis',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const aboutcomfortiscontent = new utilities.aboutcomfortisPage();
     const entry = entries.items[0];
     aboutcomfortiscontent.bannertext = entry.fields.bannertext;
     if (entry.fields.bannerimage !== undefined) {
       aboutcomfortiscontent.bannerimage = entry.fields.bannerimage.fields.file.url;
     }
     aboutcomfortiscontent.menu = entry.fields.menu;
     aboutcomfortiscontent.title1 = entry.fields.title1;
     aboutcomfortiscontent.content1 = entry.fields.content1;
     aboutcomfortiscontent.familyfriendly = entry.fields.familyfriendly;
     aboutcomfortiscontent.title2 = entry.fields.title2;
     aboutcomfortiscontent.title2content = entry.fields.title2content;
     aboutcomfortiscontent.textli = entry.fields.textli;
    //  aboutcomfortiscontent.viewthecomfortis = entry.fields.viewthecomfortis;
    //  console.log(".................");
    //  console.log(aboutcomfortiscontent.viewthecomfortis);
     aboutcomfortiscontent.buttonText = entry.fields.buttonText;
     aboutcomfortiscontent.buttonUrl = entry.fields.buttonUrl;
     aboutcomfortiscontent.askyourvettext = entry.fields.askyourvettext;
     aboutcomfortiscontent.greenchemistrytitle = entry.fields.greenchemistrytitle;
     aboutcomfortiscontent.greenchemistrycontent = entry.fields.greenchemistrycontent;
     if (entry.fields.image1 !== undefined) {
       aboutcomfortiscontent.image1 = entry.fields.image1.fields.file.url;
     }
     if (entry.fields.greenchemistryimage !== undefined) {
       aboutcomfortiscontent.greenchemistryimage = entry.fields.greenchemistryimage.fields.file.url;
     }
     if (entry.fields.image2 !== undefined) {
       aboutcomfortiscontent.image2 = entry.fields.image2.fields.file.url;
     }
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       aboutcomfortiscontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       aboutcomfortiscontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       aboutcomfortiscontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       aboutcomfortiscontent.dvmstaff.push(oLink);
     }
     const references = entry.fields.references;
     for (let i = 0; i < references.length; i++) {
       const oLink = new utilities.references();
       oLink.references = references[i].fields.references;
       aboutcomfortiscontent.references.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     /*eslint-disable*/
     var viewthecomfortis = entry.fields.viewthecomfortis;
     var myRegex = /{(.*)}/g;
     var matches1 = [];
 	   var match1 = myRegex.exec(viewthecomfortis);
     while (match1 != null) {
       matches1.push(match1[1]);
       match1 = myRegex.exec(viewthecomfortis);
     }
     var index=0;
     global.ImageUrl = [];
     async.asyncLoop(matches1.length, function(loop) {
       async.getImage(matches1[index], function(result) {
         index++;
         loop.next();
         })},
         function(){
            for(var i= 0;i < global.ImageUrl.length; i++)
            {
            viewthecomfortis  = viewthecomfortis.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
            }
          aboutcomfortiscontent.viewthecomfortis = viewthecomfortis;
           console.log(".................");
           console.log(aboutcomfortiscontent.viewthecomfortis);
           global.aboutcomfortiscontent = aboutcomfortiscontent;
           res.render('about-comfortis', {
      /* eslint-disable comma-dangle */
             aboutcomfortisPage: aboutcomfortiscontent
          /* eslint-enable comma-dangle */
           });
     }
  );


   });
 };
