/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getaboutfleasPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'aboutfleas',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const aboutfleascontent = new utilities.aboutfleasPage();
     const entry = entries.items[0];
     aboutfleascontent.bannertitle = entry.fields.bannertitle;
     if (entry.fields.bannerimage !== undefined) {
       aboutfleascontent.bannerimage = entry.fields.bannerimage.fields.file.url;
     }
     aboutfleascontent.howtogetridcontent = entry.fields.howtogetridcontent;
     aboutfleascontent.learnmoreaboutcomfirtis = entry.fields.learnmoreaboutcomfirtis;
     aboutfleascontent.learnmoreaboutcomfortisurls = entry.fields.learnmoreaboutcomfortisurls;
     aboutfleascontent.askaveteriantext = entry.fields.askaveteriantext;
     aboutfleascontent.askavetcontent = entry.fields.askavetcontent;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       aboutfleascontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       aboutfleascontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       aboutfleascontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       aboutfleascontent.dvmstaff.push(oLink);
     }
     aboutfleascontent.leftnav = entry.fields.leftnav;
     aboutfleascontent.videoUrl1 = entry.fields.videoUrl1;
     aboutfleascontent.videoText1 = entry.fields.videoText1;
     aboutfleascontent.pdf1 = entry.fields.pdf1;
     aboutfleascontent.videoUrl2 = entry.fields.videoUrl2;
     aboutfleascontent.videoText2 = entry.fields.videoText2;
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.aboutfleascontent = aboutfleascontent;
     res.render('about-fleas', {
/* eslint-disable comma-dangle */
       aboutfleasPage: aboutfleascontent
    /* eslint-enable comma-dangle */
     });
   });
 };
