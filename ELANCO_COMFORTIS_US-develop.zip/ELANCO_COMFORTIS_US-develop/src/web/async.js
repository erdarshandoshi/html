/* eslint-disable linebreak-style*/
/* eslint-disable */

module.exports = {

findImage : function(array,mcallback)
{
  var descriptionContent = array.fields.pdfUrl;
  var myRegex = /{(.*)}/g;
  var match1 = myRegex.exec(descriptionContent);
  var oLink = [];
  console.log("...............");
  console.log(descriptionContent);
  console.log("////////////////////");
  console.log(match1);

  while (match1 != null) {
      oLink.push(match1[1]);
      match1 = myRegex.exec(descriptionContent);
  }
  var innerIndex = 0;
  module.exports.asyncLoop(oLink.length, function(loop) {
          module.exports.getImage(oLink[innerIndex], function(result) {
                      innerIndex++;
                      loop.next();
                      })},
                 function(){
                    mcallback();
                 });

},
getImage : function(id,callback)
{
   global.cfClient.getAsset(id)
          .then((reponse)  => {
              ImageUrl.push({id: id, url : reponse.fields.file.url});
              callback();
    }).catch((reponse)  => {
        callback();
    });
},
 asyncLoop : function(iterations, func, callback)
    {
    var index = 0;
    var done = false;
    var loop = {
        next: function() {
            if (done) {
                return;
            }

            if (index < iterations) {
                index++;
                func(loop);

            } else {
                done = true;
                callback();
            }
        },

        iteration: function() {
            return index - 1;
        },

        break: function() {
            done = true;
            callback();
        }
    };
    loop.next();
    return loop;
    }
}
