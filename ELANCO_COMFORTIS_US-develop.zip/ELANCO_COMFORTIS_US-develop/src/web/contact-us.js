/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getcontactusPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'contactus',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const contactuscontent = new utilities.contactusPage();
     const entry = entries.items[0];
     contactuscontent.contactustitle = entry.fields.contactustitle;
     if (entry.fields.contactusimage !== undefined) {
       contactuscontent.contactusimage = entry.fields.contactusimage.fields.file.url;
     }
     contactuscontent.howtogetintouch = entry.fields.howtogetintouch;
     contactuscontent.productinfo = entry.fields.productinfo;
     contactuscontent.number = entry.fields.number;
     contactuscontent.mediacontacts = entry.fields.mediacontacts;
     contactuscontent.mediacontactsdescription = entry.fields.mediacontactsdescription;
     contactuscontent.address = entry.fields.address;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       contactuscontent.learnhowtogetcomfortis.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       contactuscontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       contactuscontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.contactuscontent = contactuscontent;
     res.render('contact-us', {
/* eslint-disable comma-dangle */
       contactusPage: contactuscontent
    /* eslint-enable comma-dangle */
     });
   });
 };
