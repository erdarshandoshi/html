/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');
 const async = require('../web/async');
/* global app.js cfClient:true appLocale:true*/
 exports.getcontrollingfleasPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'controllingfleas',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const controllingfleascontent = new utilities.controllingfleasPage();
     const entry = entries.items[0];
     controllingfleascontent.controllingfleastitle = entry.fields.controllingfleastitle;
     if (entry.fields.image !== undefined) {
       controllingfleascontent.image = entry.fields.image.fields.file.url;
     }
     controllingfleascontent.menu = entry.fields.menu;
     controllingfleascontent.howtogetridfleas = entry.fields.howtogetridfleas;
     controllingfleascontent.howtogetridfleascontent = entry.fields.howtogetridfleascontent;
     controllingfleascontent.howtocontrolfleastitle = entry.fields.howtocontrolfleastitle;
     controllingfleascontent.forfleastitle = entry.fields.forfleastitle;
     controllingfleascontent.fleasli = entry.fields.fleasli;
     controllingfleascontent.viewfaqs = entry.fields.viewfaqs;
     controllingfleascontent.viewfaqsurl = entry.fields.viewfaqsurl;
     controllingfleascontent.tipstofree = entry.fields.tipstofree;
     controllingfleascontent.tipstofreecontent = entry.fields.tipstofreecontent;
     controllingfleascontent.killingfleastitle = entry.fields.killingfleastitle;
     controllingfleascontent.killingfleascontent = entry.fields.killingfleascontent;
     controllingfleascontent.preventingfuturetitle = entry.fields.preventingfuturetitle;
    //  controllingfleascontent.preventingfuturecontent = entry.fields.preventingfuturecontent;
     controllingfleascontent.howtogetcomfortistitle = entry.fields.howtogetcomfortistitle;
     controllingfleascontent.howtogetcomfortisurl = entry.fields.howtogetcomfortisurl;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       controllingfleascontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       controllingfleascontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       controllingfleascontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       controllingfleascontent.dvmstaff.push(oLink);
     }
     const references = entry.fields.references;
     for (let i = 0; i < references.length; i++) {
       const oLink = new utilities.references();
       oLink.references = references[i].fields.references;
       controllingfleascontent.references.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     /*eslint-disable*/
     var preventingfuturecontent = entry.fields.preventingfuturecontent;
     var myRegex = /{(.*)}/g;
     var matches1 = [];
    var match1 = myRegex.exec(preventingfuturecontent);
     while (match1 != null) {
       matches1.push(match1[1]);
       match1 = myRegex.exec(preventingfuturecontent);
     }
     var index=0;
     global.ImageUrl = [];
     async.asyncLoop(matches1.length, function(loop) {
             async.getImage(matches1[index], function(result) {
               index++;
               loop.next();
               })},
               function(){
                  for(var i= 0;i < global.ImageUrl.length; i++)
                  {
                  preventingfuturecontent  = preventingfuturecontent.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  // rightSideContent  = rightSideContent.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  }
                controllingfleascontent.preventingfuturecontent = preventingfuturecontent;
                     global.flealifecyclecontent = controllingfleascontent;
                     res.render('controlling-fleas', {
                /* eslint-disable comma-dangle */
                       controllingfleasPage: controllingfleascontent
                    /* eslint-enable comma-dangle */
                     });
           }
        );
   });
 };
