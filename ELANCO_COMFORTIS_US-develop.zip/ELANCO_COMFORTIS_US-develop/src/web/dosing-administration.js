/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getdosingadministrationPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'dosingandadministration',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const dosingandadministrationcontent = new utilities.dosingandadministrationPage();
     const entry = entries.items[0];
     dosingandadministrationcontent.bannertitle = entry.fields.bannertitle;
     if (entry.fields.bannerimage !== undefined) {
       dosingandadministrationcontent.bannerimage = entry.fields.bannerimage.fields.file.url;
     }
     dosingandadministrationcontent.menu = entry.fields.menu;
     dosingandadministrationcontent.howtogivetitle = entry.fields.howtogivetitle;
     const howtogivecontent = entry.fields.howtogivecontent;
     for (let i = 0; i < howtogivecontent.length; i++) {
       const oLink = new utilities.howtogivecontent();
       if (howtogivecontent[i].fields.icon !== undefined) {
         oLink.icon = howtogivecontent[i].fields.icon.fields.file.url;
       }
       oLink.content = howtogivecontent[i].fields.content;
       oLink.altText = howtogivecontent[i].fields.altText;
       dosingandadministrationcontent.howtogivecontent.push(oLink);
     }
     dosingandadministrationcontent.dosinginformation = entry.fields.dosinginformation;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       dosingandadministrationcontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       dosingandadministrationcontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       dosingandadministrationcontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       dosingandadministrationcontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     global.dosingandadministrationcontent = dosingandadministrationcontent;
     res.render('dosing-administration', {
/* eslint-disable comma-dangle */
       dosingandadministrationPage: dosingandadministrationcontent
    /* eslint-enable comma-dangle */
     });
   });
 };
