/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getflealifecyclePage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'flealifecycle',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const flealifecyclecontent = new utilities.flealifecyclePage();
     const entry = entries.items[0];
     flealifecyclecontent.flealifecycletitle = entry.fields.flealifecycletitle;
     if (entry.fields.flealifecycleimage !== undefined) {
       flealifecyclecontent.flealifecycleimage = entry.fields.flealifecycleimage.fields.file.url;
     }
     flealifecyclecontent.menu = entry.fields.menu;
     flealifecyclecontent.stoppingafleatitle = entry.fields.stoppingafleatitle;
     flealifecyclecontent.stoppingafleacontent = entry.fields.stoppingafleacontent;
     if (entry.fields.lifecycleimage !== undefined) {
       flealifecyclecontent.lifecycleimage = entry.fields.lifecycleimage.fields.file.url;
     }
     flealifecyclecontent.howmypetgetfleas = entry.fields.howmypetgetfleas;
     flealifecyclecontent.comfortisspinosadtitle = entry.fields.comfortisspinosadtitle;
     flealifecyclecontent.content = entry.fields.content;
     flealifecyclecontent.learnmoreaboutbuttontitle = entry.fields.learnmoreaboutbuttontitle;
     flealifecyclecontent.learnmoreaboutbuttonurl = entry.fields.learnmoreaboutbuttonurl;
     flealifecyclecontent.videotitle = entry.fields.videotitle;
     flealifecyclecontent.videourl = entry.fields.videourl;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       flealifecyclecontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       flealifecyclecontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       flealifecyclecontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       flealifecyclecontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.flealifecyclecontent = flealifecyclecontent;
     res.render('flea-life-cycle', {
/* eslint-disable comma-dangle */
       flealifecyclePage: flealifecyclecontent
    /* eslint-enable comma-dangle */
     });
   });
 };
