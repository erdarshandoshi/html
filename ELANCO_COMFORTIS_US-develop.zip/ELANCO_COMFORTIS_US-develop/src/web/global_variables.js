 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true next:true appServer:true*/

 function setHeader() {
   cfClient.getEntries({
     content_type: 'header',
     locale: appLocale,
     include: '2',
   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const entry = entries.items[0];
     const headerContent = new utilities.masterPageHeader();
     headerContent.headerLogo = entry.fields.headerLogo.fields.file.url;
     headerContent.headerLogoUrl = entry.fields.headerLogoUrl;
     const columns = entry.fields.headerMenuLink;
     for (let i = 0; i < columns.length; i++) {
       const oLink = new utilities.headerMenuLink();
      //  console.log(columns[i].fields.menuName);
       oLink.menuName = columns[i].fields.menuName;
       oLink.menuUrl = columns[i].fields.menuUrl;
       if (columns[i].fields.class !== undefined) {
         oLink.class = columns[i].fields.class;
       }
       if (columns[i].fields.style !== undefined) {
         oLink.style = columns[i].fields.style;
       }
       oLink.haveleftnav = false;
       if (columns[i].fields.leftnav !== undefined) {
         const columns1 = columns[i].fields.leftnav;
         for (let j = 0; j < columns1.length; j++) {
           const oLink1 = new utilities.leftnav();
           oLink.haveleftnav = true;
           console.log(columns1[j].fields.pagename);
           oLink1.pagename = columns1[j].fields.pagename;
           oLink1.pageurl = columns1[j].fields.pageurl;
           oLink1.class = columns1[j].fields.class;
           oLink1.style = columns1[j].fields.style;
           oLink.leftnav.push(oLink1);
         }
       }
       headerContent.headerMenuLink.push(oLink);
     }
     global.appServer.locals.headerContent = headerContent;
   });
 }

 function setFooter() {
   cfClient.getEntries({
     content_type: 'footer',
     locale: global.appLocale,
   }).then((entries) => {
     const footercontent = new utilities.masterPageFooter();
     const entry = entries.items[0];
     footercontent.copyText = entry.fields.copyText;
     footercontent.zincCode = entry.fields.zincCode;
     footercontent.elancoLogo = entry.fields.elancoLogo.fields.file.url;
     footercontent.elancoUrl = entry.fields.elancoUrl;
     const footerMenuLink = entry.fields.footerMenuLink;
     for (let k = 0; k < footerMenuLink.length; k++) {
       const oLink2 = new utilities.footerMenuLink();
       oLink2.menuName = footerMenuLink[k].fields.menuName;
       oLink2.menuUrl = footerMenuLink[k].fields.menuUrl;
       footercontent.footerMenuLink.push(oLink2);
     }
     appServer.locals.footercontent = footercontent;
   });
 }
 function resetGlobals() {
   global.homecontent = {};
 }
 exports.GetGlobalEntriesAppData = () => {
   setHeader();
   setFooter();
   resetGlobals();
 };
