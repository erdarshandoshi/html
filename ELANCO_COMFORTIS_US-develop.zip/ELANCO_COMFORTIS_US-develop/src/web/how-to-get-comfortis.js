/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');
 const async = require('../web/async');
/* global app.js cfClient:true appLocale:true*/
 exports.gethowtogetcomfortisPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'howtogetcomfortis',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const howtogetcomfortiscontent = new utilities.howtogetcomfortisPage();
     const entry = entries.items[0];
     howtogetcomfortiscontent.bannertitle = entry.fields.bannertitle;
     if (entry.fields.bannerimage !== undefined) {
       howtogetcomfortiscontent.bannerimage = entry.fields.bannerimage.fields.file.url;
     }
     howtogetcomfortiscontent.menu = entry.fields.menu;
     howtogetcomfortiscontent.title1 = entry.fields.title1;
     howtogetcomfortiscontent.titlecontent = entry.fields.titlecontent;
     // howtogetcomfortiscontent.blueicon = entry.fields.blueicon;
     howtogetcomfortiscontent.save25buttontitle = entry.fields.save25buttontitle;
     howtogetcomfortiscontent.save25buttonurl = entry.fields.save25buttonurl;
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       howtogetcomfortiscontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       howtogetcomfortiscontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       howtogetcomfortiscontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     /*eslint-disable*/
     var blueicon = entry.fields.blueicon;
     var myRegex = /{(.*)}/g;
     var matches1 = [];
    var match1 = myRegex.exec(blueicon);
     while (match1 != null) {
       matches1.push(match1[1]);
       match1 = myRegex.exec(blueicon);
     }
     var index=0;
     global.ImageUrl = [];
     async.asyncLoop(matches1.length, function(loop) {
             async.getImage(matches1[index], function(result) {
               index++;
               loop.next();
               })},
               function(){
                  for(var i= 0;i < global.ImageUrl.length; i++)
                  {
                  blueicon  = blueicon.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  // rightSideContent  = rightSideContent.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  }
                howtogetcomfortiscontent.blueicon = blueicon;

                     global.howtogetcomfortiscontent = howtogetcomfortiscontent;
                     res.render('how-to-get-comfortis', {
                /* eslint-disable comma-dangle */
                       howtogetcomfortisPage: howtogetcomfortiscontent
                    /* eslint-enable comma-dangle */
                     });
           }
        );

   });
 };
