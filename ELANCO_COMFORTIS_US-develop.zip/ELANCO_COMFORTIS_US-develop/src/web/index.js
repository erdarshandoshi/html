/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getIndexPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'home',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const homecontent = new utilities.homePage();
     const entry = entries.items[0];
     homecontent.prescribedText = entry.fields.prescribedText;
     homecontent.saveText = entry.fields.saveText;
     homecontent.saveUrl = entry.fields.saveUrl;
     homecontent.learnWhyButton = entry.fields.learnWhyButton;
     console.log(homecontent.learnWhyButton);
     homecontent.learnWhyButtonUrl = entry.fields.learnWhyButtonUrl;
     homecontent.fleaMedicineText = entry.fields.fleaMedicineText;
     if (entry.fields.bannerimage2 !== undefined) {
       homecontent.bannerimage2 = entry.fields.bannerimage2.fields.file.url;
     }
     homecontent.bannercontent2 = entry.fields.bannercontent2;
     homecontent.mandatory = entry.fields.mandatory;
     homecontent.banner3 = entry.fields.banner3;
     homecontent.banner1Title = entry.fields.banner1Title;
     homecontent.banner1BottomText = entry.fields.banner1BottomText;
     homecontent.image = entry.fields.image.fields.file.url;
     homecontent.imagemobile = entry.fields.imagemobile.fields.file.url;
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       homecontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink1 = new utilities.about();
       oLink1.name = about[i].fields.name;
       oLink1.url = about[i].fields.url;
       homecontent.about.push(oLink1);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink2 = new utilities.dvmstaff();
       oLink2.name = dvmstaff[i].fields.name;
       oLink2.url = dvmstaff[i].fields.url;
       homecontent.dvmstaff.push(oLink2);
     }
     const references = entry.fields.references;
     for (let i = 0; i < references.length; i++) {
       const oLink3 = new utilities.references();
       oLink3.references = references[i].fields.references;
       homecontent.references.push(oLink3);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.homecontent = homecontent;
     res.render('index', {
/* eslint-disable comma-dangle */
       homePage: homecontent
    /* eslint-enable comma-dangle */
     });
   });
 };
