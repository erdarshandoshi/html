/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getourGuranteePage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'ourGurantee',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const ourGuranteecontent = new utilities.ourGuranteePage();
     const entry = entries.items[0];
     ourGuranteecontent.ourguranteetitle = entry.fields.ourguranteetitle;
     if (entry.fields.ourgurantee !== undefined) {
       ourGuranteecontent.ourgurantee = entry.fields.ourgurantee.fields.file.url;
     }
     ourGuranteecontent.productgurante = entry.fields.productgurante;
     ourGuranteecontent.content = entry.fields.content;
     if (entry.fields.fleaicon !== undefined) {
       ourGuranteecontent.fleaicon = entry.fields.fleaicon.fields.file.url;
     }
     ourGuranteecontent.fleatitle = entry.fields.fleatitle;
     ourGuranteecontent.fleacontent = entry.fields.fleacontent;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       ourGuranteecontent.learnhowtogetcomfortis.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       ourGuranteecontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       ourGuranteecontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.ourGuranteecontent = ourGuranteecontent;
     res.render('our-guarantee', {
/* eslint-disable comma-dangle */
       ourGuranteePage: ourGuranteecontent
    /* eslint-enable comma-dangle */
     });
   });
 };
