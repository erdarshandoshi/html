/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getourpartnersPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'ourpartners',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const ourpartnerscontent = new utilities.ourpartnersPage();
     const entry = entries.items[0];
     ourpartnerscontent.ourpartnerstitle = entry.fields.ourpartnerstitle;
     if (entry.fields.ourpartnerimage !== undefined) {
       ourpartnerscontent.ourpartnerimage = entry.fields.ourpartnerimage.fields.file.url;
     }
     ourpartnerscontent.supportingthosetitle = entry.fields.supportingthosetitle;
     const partnermenu = entry.fields.partnermenu;
     for (let i = 0; i < partnermenu.length; i++) {
       const oLink = new utilities.partnermenu();
       oLink.partnertitle = partnermenu[i].fields.partnertitle;
       if (partnermenu[i].fields.partnerimg !== undefined) {
         oLink.partnerimg = partnermenu[i].fields.partnerimg.fields.file.url;
       }
       oLink.partnercontent = partnermenu[i].fields.partnercontent;
       ourpartnerscontent.partnermenu.push(oLink);
     }
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       ourpartnerscontent.learnhowtogetcomfortis.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       ourpartnerscontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       ourpartnerscontent.dvmstaff.push(oLink);
     }
     const references = entry.fields.references;
     for (let i = 0; i < references.length; i++) {
       const oLink = new utilities.references();
       oLink.references = references[i].fields.references;
       ourpartnerscontent.references.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     global.ourpartnerscontent = ourpartnerscontent;
     res.render('our-partners', {
/* eslint-disable comma-dangle */
       ourpartnersPage: ourpartnerscontent
    /* eslint-enable comma-dangle */
     });
   });
 };
