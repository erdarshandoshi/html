/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getpageNotFoundPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'pageNotFound',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const pageNotFoundcontent = new utilities.pageNotFoundPage();
     const entry = entries.items[0];
     pageNotFoundcontent.bannerText = entry.fields.bannerText;
     pageNotFoundcontent.buttonText = entry.fields.buttonText;
     pageNotFoundcontent.buttonUrl = entry.fields.buttonUrl;
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       pageNotFoundcontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;

       console.log(oLink.name);
       oLink.url = dvmstaff[i].fields.url;
       pageNotFoundcontent.dvmstaff.push(oLink);
     }
    //  global.appServer.locals.metaDescription = entry.fields.metaDescription;
    //  global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
    //  global.appServer.locals.title = entry.fields.title;
    //  global.appServer.locals.pageId = entry.fields.pageId;
    //  global.appServer.locals.title = entry.fields.title;

     global.pageNotFoundcontent = pageNotFoundcontent;
     res.render('page-not-found', {
/* eslint-disable comma-dangle */
       pageNotFoundPage: pageNotFoundcontent
    /* eslint-enable comma-dangle */
     });
   });
 };
