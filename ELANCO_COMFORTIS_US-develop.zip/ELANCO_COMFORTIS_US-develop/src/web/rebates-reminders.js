/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');
 const async = require('../web/async');
/* global app.js cfClient:true appLocale:true*/
 exports.getrebatesremindersPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'rebatesreminders',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const rebatesreminderscontent = new utilities.rebatesremindersPage();
     const entry = entries.items[0];
     rebatesreminderscontent.rebatesreminderstitle = entry.fields.rebatesreminderstitle;
     if (entry.fields.image !== undefined) {
       rebatesreminderscontent.image = entry.fields.image.fields.file.url;
     }
     rebatesreminderscontent.rebateofferstext = entry.fields.rebateofferstext;
     rebatesreminderscontent.rebateofferssubtext = entry.fields.rebateofferssubtext;
     // rebatesreminderscontent.blueicon = entry.fields.blueicon;
     rebatesreminderscontent.visitrebatebutton = entry.fields.visitrebatebutton;
     rebatesreminderscontent.visitrebatebuttonurl = entry.fields.visitrebatebuttonurl;
     rebatesreminderscontent.remindertitle = entry.fields.remindertitle;
     rebatesreminderscontent.reminderssubtitle = entry.fields.reminderssubtitle;
     rebatesreminderscontent.reminderscontent = entry.fields.reminderscontent;
     rebatesreminderscontent.signupbutton = entry.fields.signupbutton;
     rebatesreminderscontent.signupbuttonurl = entry.fields.signupbuttonurl;
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       rebatesreminderscontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       rebatesreminderscontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       rebatesreminderscontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     /*eslint-disable*/
     var blueicon = entry.fields.blueicon;
     var myRegex = /{(.*)}/g;
     var matches1 = [];
    var match1 = myRegex.exec(blueicon);
     while (match1 != null) {
       matches1.push(match1[1]);
       match1 = myRegex.exec(blueicon);
     }
     var index=0;
     global.ImageUrl = [];
     async.asyncLoop(matches1.length, function(loop) {
             async.getImage(matches1[index], function(result) {
               index++;
               loop.next();
               })},
               function(){
                  for(var i= 0;i < global.ImageUrl.length; i++)
                  {
                  blueicon  = blueicon.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  // rightSideContent  = rightSideContent.replace("{"+global.ImageUrl[i].id+"}", global.ImageUrl[i].url);
                  }
                rebatesreminderscontent.blueicon = blueicon;

             global.rebatesreminderscontent = rebatesreminderscontent;
             res.render('rebates-reminders', {
        /* eslint-disable comma-dangle */
               rebatesremindersPage: rebatesreminderscontent
            /* eslint-enable comma-dangle */
             });
           }
        );
   });
 };
