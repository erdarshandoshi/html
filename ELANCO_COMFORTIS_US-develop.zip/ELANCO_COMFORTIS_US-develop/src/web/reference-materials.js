/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getreferencematerialPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'referencematerial',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const referencematerialcontent = new utilities.referencematerialPage();
     const entry = entries.items[0];
     referencematerialcontent.referencetitle = entry.fields.referencetitle;
     if (entry.fields.referenceimg !== undefined) {
       referencematerialcontent.referenceimg = entry.fields.referenceimg.fields.file.url;
     }
     referencematerialcontent.comfortistitle = entry.fields.comfortistitle;
     referencematerialcontent.comfortiscontent = entry.fields.comfortiscontent;
     referencematerialcontent.productinfotitle = entry.fields.productinfotitle;
     referencematerialcontent.productinfocontent = entry.fields.productinfocontent;
     referencematerialcontent.fdainfo = entry.fields.fdainfo;
     referencematerialcontent.fdacontent = entry.fields.fdacontent;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       referencematerialcontent.learnhowtogetcomfortis.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       referencematerialcontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       referencematerialcontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;

     global.referencematerialcontent = referencematerialcontent;
     res.render('reference-materials', {
/* eslint-disable comma-dangle */
       referencematerialPage: referencematerialcontent
    /* eslint-enable comma-dangle */
     });
   });
 };
