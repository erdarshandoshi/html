/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getsitemapPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'sitemap',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const sitemapcontent = new utilities.sitemapPage();
     const entry = entries.items[0];
     sitemapcontent.sitemaptitle = entry.fields.sitemaptitle;
     sitemapcontent.aboutcomfortistitle = entry.fields.aboutcomfortistitle;
     const aboutcomfortismenu = entry.fields.aboutcomfortismenu;
     for (let i = 0; i < aboutcomfortismenu.length; i++) {
       const oLink = new utilities.aboutcomfortismenu();
       oLink.name = aboutcomfortismenu[i].fields.name;
       oLink.url = aboutcomfortismenu[i].fields.url;
       sitemapcontent.aboutcomfortismenu.push(oLink);
     }
     sitemapcontent.aboutfleastitle = entry.fields.aboutfleastitle;
     const aboutfleasmenu = entry.fields.aboutfleasmenu;
     for (let i = 0; i < aboutfleasmenu.length; i++) {
       const oLink = new utilities.aboutfleasmenu();
       oLink.name = aboutfleasmenu[i].fields.name;
       oLink.url = aboutfleasmenu[i].fields.url;
       sitemapcontent.aboutfleasmenu.push(oLink);
     }
     sitemapcontent.faqstitle = entry.fields.faqstitle;
     const faqsmenu = entry.fields.faqsmenu;
     for (let i = 0; i < faqsmenu.length; i++) {
       const oLink = new utilities.faqsmenu();
       oLink.pagename = faqsmenu[i].fields.pagename;
       oLink.pageurl = faqsmenu[i].fields.pageurl;
       sitemapcontent.faqsmenu.push(oLink);
     }
     sitemapcontent.rebatesreminderstitle = entry.fields.rebatesreminderstitle;
     sitemapcontent.rebatesremindersurl = entry.fields.rebatesremindersurl;
     sitemapcontent.aboutelancotitle = entry.fields.aboutelancotitle;
     const aboutelancomenu = entry.fields.aboutelancomenu;
     for (let i = 0; i < aboutelancomenu.length; i++) {
       const oLink = new utilities.aboutelancomenu();
       oLink.name = aboutelancomenu[i].fields.name;
       oLink.url = aboutelancomenu[i].fields.url;
       sitemapcontent.aboutelancomenu.push(oLink);
     }
     sitemapcontent.dvmstafftitle = entry.fields.dvmstafftitle;
     const dvmstaffmenu = entry.fields.dvmstaffmenu;
     for (let i = 0; i < dvmstaffmenu.length; i++) {
       const oLink = new utilities.dvmstaffmenu();
       oLink.name = dvmstaffmenu[i].fields.name;
       oLink.url = dvmstaffmenu[i].fields.url;
       sitemapcontent.dvmstaffmenu.push(oLink);
     }
     sitemapcontent.privacystatementtitle = entry.fields.privacystatementtitle;
     sitemapcontent.privacystatementurl = entry.fields.privacystatementurl;
     sitemapcontent.trademarkText = entry.fields.trademarkText;
     sitemapcontent.trademarkUrl = entry.fields.trademarkUrl;
     sitemapcontent.termsOfUseText = entry.fields.termsOfUseText;
     sitemapcontent.termsOfUseUrl = entry.fields.termsOfUseUrl;
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       sitemapcontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       sitemapcontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.sitemapcontent = sitemapcontent;
     res.render('site-map', {
/* eslint-disable comma-dangle */
       sitemapPage: sitemapcontent
    /* eslint-enable comma-dangle */
     });
   });
 };
