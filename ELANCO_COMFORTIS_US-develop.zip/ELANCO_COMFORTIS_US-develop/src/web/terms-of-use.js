/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.gettermsOfUsePage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'termsOfUse',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const termsOfUsecontent = new utilities.termsOfUsePage();
     const entry = entries.items[0];
     termsOfUsecontent.title = entry.fields.title;
     termsOfUsecontent.description = entry.fields.description;
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       termsOfUsecontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       termsOfUsecontent.dvmstaff.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.termsOfUsecontent = termsOfUsecontent;
     res.render('terms-of-use', {
/* eslint-disable comma-dangle */
       termsOfUsePage: termsOfUsecontent
    /* eslint-enable comma-dangle */
     });
   });
 };
