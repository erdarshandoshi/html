/* eslint-disable linebreak-style*/
 const utilities = require('../web/Utilities');

/* global app.js cfClient:true appLocale:true*/
 exports.getwhatarefleasPage = (req, res, next) => {
   cfClient.getEntries({
     content_type: 'whatarefleas',
/* eslint-disable comma-dangle */
     locale: appLocale
     /* eslint-enable comma-dangle */

   }).then((entries) => {
     if (entries.total !== 1) {
       const err = new Error('Error in fetching Home pages entry.');
       err.status = 404;
       next(err);
     }
     const whatarefleascontent = new utilities.whatarefleasPage();
     const entry = entries.items[0];
     whatarefleascontent.whatarefleasbannertext = entry.fields.whatarefleasbannertext;
     if (entry.fields.whatarefleaesimage !== undefined) {
       whatarefleascontent.whatarefleaesimage = entry.fields.whatarefleaesimage.fields.file.url;
     }
     whatarefleascontent.leftnav = entry.fields.leftnav;
     whatarefleascontent.herewhatyouneed = entry.fields.herewhatyouneed;
     whatarefleascontent.herewhatyouneedcontent = entry.fields.herewhatyouneedcontent;
     whatarefleascontent.buttonText = entry.fields.buttonText;
     whatarefleascontent.buttonUrl = entry.fields.buttonUrl;
     whatarefleascontent.petthreat = entry.fields.petthreat;
     whatarefleascontent.humanthreattitle = entry.fields.humanthreattitle;
     whatarefleascontent.humanthreat = entry.fields.humanthreat;
     whatarefleascontent.buttonText1 = entry.fields.buttonText1;
     whatarefleascontent.buttonUrl1 = entry.fields.buttonUrl1;
     const learnhowtogetcomfortis = entry.fields.learnhowtogetcomfortis;
     for (let i = 0; i < learnhowtogetcomfortis.length; i++) {
       const oLink = new utilities.learnhowtogetcomfortis();
       oLink.learnhow = learnhowtogetcomfortis[i].fields.learnhow;
       whatarefleascontent.learnhowtogetcomfortis.push(oLink);
     }
     const impSafetyInfo = entry.fields.impSafetyInfo;
     for (let i = 0; i < impSafetyInfo.length; i++) {
       const oLink = new utilities.impSafetyInfo();
       oLink.impSafetyTitle = impSafetyInfo[i].fields.impSafetyTitle;
       oLink.impSafetyContent = impSafetyInfo[i].fields.impSafetyContent;
       whatarefleascontent.impSafetyInfo.push(oLink);
     }
     const about = entry.fields.about;
     for (let i = 0; i < about.length; i++) {
       const oLink = new utilities.about();
       oLink.name = about[i].fields.name;
       oLink.url = about[i].fields.url;
       whatarefleascontent.about.push(oLink);
     }
     const dvmstaff = entry.fields.dvmstaff;
     for (let i = 0; i < dvmstaff.length; i++) {
       const oLink = new utilities.dvmstaff();
       oLink.name = dvmstaff[i].fields.name;
       oLink.url = dvmstaff[i].fields.url;
       whatarefleascontent.dvmstaff.push(oLink);
     }
     const references = entry.fields.references;
     for (let i = 0; i < references.length; i++) {
       const oLink = new utilities.references();
       oLink.references = references[i].fields.references;
       whatarefleascontent.references.push(oLink);
     }
     global.appServer.locals.metaDescription = entry.fields.metaDescription;
     global.appServer.locals.metaKeyword = entry.fields.metaKeyword;
     global.appServer.locals.title = entry.fields.title;
     global.appServer.locals.pageId = entry.fields.pageId;
     global.appServer.locals.pageTitle = entry.fields.pageTitle;
     global.whatarefleascontent = whatarefleascontent;
     res.render('what-are-fleas', {
/* eslint-disable comma-dangle */
       whatarefleasPage: whatarefleascontent
    /* eslint-enable comma-dangle */
     });
   });
 };
